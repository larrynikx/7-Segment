#include "_7SEG.h"


_7SEG *_ptr;
volatile double _val=0;
volatile bool _dp_flag=false;



int _7SEG::_map[16] = {0xDB,0x41,0x9D,0xED,0x47,0xCE,0xDE,0xC1,
                       0xDF,0xC7,0xD7,0x5E,0x9A,0x5D,0x9E,0x96};

_7SEG::_7SEG(int S1_PIN,int S2_PIN,int SR_CLK,int ST_CLK,int D_PIN) : _S1_PIN(S1_PIN),_S2_PIN(S2_PIN),_SR_CLK(SR_CLK),_ST_CLK(ST_CLK),_D_PIN(D_PIN){
    pinMode(_S1_PIN,OUTPUT);
    pinMode(_S2_PIN,OUTPUT);
    pinMode(_SR_CLK,OUTPUT);
    pinMode(_ST_CLK,OUTPUT);
    pinMode(_D_PIN,OUTPUT);

    noInterrupts();
    //set timer1 interrupt to 200Hz

    TCCR1A = 0; //Set timer counter control registers to 0
    TCCR1B = 0;
    TCNT1=0; //initialize counter value to 0

    OCR1A = 12; //set compare match register for 200Hz increments with a 1024 prescaler
    TCCR1B |= (1 << WGM12); //  turn on CTC mode
    TCCR1B |= (1 << CS12) | (1 << CS10); //set CS10 and CS12 bits for 1024 prescaler
    TIMSK1 |= (1 << OCIE1A); //enable timer compare interrupt
    interrupts();

    _ptr=this;
}

bool _7SEG::isByte(int val){return val < 0x64;}
void _7SEG::writeNibble(int val,int s_line){

    digitalWrite(_ST_CLK,LOW);//pause data transfer from storage register to output
    shiftOut(_D_PIN,_SR_CLK,LSBFIRST,_dp_flag && s_line==_S2_PIN?_map[val]|_DP:_map[val]);//serial output of all bits on data pin
    digitalWrite(_ST_CLK,HIGH);//+ve edge triggered sampling, data transferred to output pins of SR

    int other_line = (s_line == _S1_PIN)?_S2_PIN:_S1_PIN;
    digitalWrite(other_line,HIGH);
    digitalWrite(s_line,LOW);//desired digit active low
    delayMicroseconds(1000);

}
void _7SEG::writeByte(double val){
    double iptr=0;
    _dp_flag = (val<0xA &&  modf(val,&iptr) != 0);
    int low_nib =  _dp_flag ? (int) (modf(val,&iptr)*0xA) : (int)val%0xA;
    int high_nib = _dp_flag ? (int) iptr : (int) val/0xA;
    mux(high_nib,low_nib);
}
void _7SEG::mux(int high_nib,int low_nib){
    writeNibble(low_nib,_S1_PIN);
    writeNibble(high_nib,_S2_PIN);
}
void _7SEG::print(double val){
    _val=val;
    delayMicroseconds(25);
}
void silent_print(){
    _ptr->writeByte(_val);
}

ISR(TIMER1_COMPA_vect){
    silent_print();
}
