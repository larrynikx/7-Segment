/*
@desc : this class displays 8 bit numbers on a 2 digit 7 segment display through an 8bit shift register.
@members : _map maps 8bit base16 numbers from the user to the corresponding SR-7SEG connection.
@NOTE : packed BCD encoding assumed for all bit manipulation
@author : Kilai Lawrence <kilailawrence@gmail.com>
*/


#ifndef _7SEG_H_INCLUDED
#define _7SEG_H_INCLUDED

#include <Arduino.h>
#include <math.h>

#define _DP 0x20
class _7SEG{
public:
    _7SEG(int S1_PIN,int S2_PIN,int SR_CLK,int ST_CLK,int D_PIN);
    void print(double val);

private:
    bool isByte(int val);
    void writeNibble(int val,int s_line);
    void writeByte(double val);
    void mux(int high_nib,int low_nib);
    friend void silent_print();

    int _S1_PIN;
    int _S2_PIN;
    int _SR_CLK;
    int _ST_CLK;
    int _D_PIN;
    static int _map[];
};
#endif // _7SEG_H_INCLUDED
